//
//  detailViewController.swift
//  Image gallery by collection view controller
//
//  Created by Mukunda Pote on 29/07/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit

class detailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var textView: UITextView!
    
    
    var sentData:String!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: sentData)
        if imageView.image == UIImage(named: "Image1"){
            
            label.text = "Image1"
            textView.text = "This is image 1"
            
        }
        
        
        if imageView.image == UIImage(named: "Image2"){
            
            label.text = "Image2"
            textView.text = "This is image 2"
            
        }
        if imageView.image == UIImage(named: "Image3"){
            
            label.text = "Image3"
            textView.text = "This is image 3"
            
        }
        if imageView.image == UIImage(named: "Image4"){
            
            label.text = "Image4"
            textView.text = "This is image 4"
            
        }
        if imageView.image == UIImage(named: "Image5"){
            
            label.text = "Image5"
            textView.text = "This is image 5"
            
        }
        if imageView.image == UIImage(named: "Image6"){
            
            label.text = "Image6"
            textView.text = "This is image 6"
            
        }
    }
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


