//
//  CollectionViewCell.swift
//  Image gallery by collection view controller
//
//  Created by Mukunda Pote on 28/07/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
}





