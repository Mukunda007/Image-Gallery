//
//  CollectionViewController.swift
//  Image gallery by collection view controller
//
//  Created by Mukunda Pote on 28/07/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class CollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    var images = ["Image1","Image2","Image3","Image4","Image5","Image6","Image1","Image2","Image3","Image4","Image5","Image6","Image1","Image2","Image3","Image4","Image5","Image6","Image1","Image2","Image3","Image4","Image5","Image6","Image1","Image2","Image3","Image4","Image5","Image6"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        
        // Do any additional setup after loading the view.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return images.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
    
        // Configure the cell
        cell.cellImage.image = UIImage(named: images[indexPath.row])
    
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let screenSize : CGRect = UIScreen.main.bounds
        var widthCell = 100
        var heightCell = 100
        
        if screenSize.width == 320 {
            widthCell = 75
            heightCell = 75
        }
        if screenSize.width == 375 {
            widthCell = 75
            heightCell = 75
        }
        if screenSize.width == 414 {
            widthCell = 75
            heightCell = 75
        }

        return CGSize(width: widthCell, height: heightCell)
    }
    
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
       if segue.identifier == "showDetail" {
        
   
            if let indexPath = self.collectionView?.indexPath(for: sender as! UICollectionViewCell){
                
                let detailView = segue.destination as! detailViewController
                
                detailView.sentData = images[indexPath.row] as String
            }
        }
    }
 
    
    
    
    
    
    
    
    
    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
